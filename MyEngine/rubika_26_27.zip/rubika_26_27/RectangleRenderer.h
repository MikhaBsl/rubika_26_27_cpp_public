#pragma once
#include <IDrawable.h>
#include <SFML/Graphics/RectangleShape.hpp>
#include <SFML/Graphics/Color.hpp>

class RectangleRenderer : public IDrawable
{
public:

	RectangleRenderer();
	~RectangleRenderer();

	// Hérité via IDrawable
	void Start() override;
	void Update(float deltaTime) override;
	void Destroy() override;

	void SetFillColor(const sf::Color& color);

	void SetTexture(const std::string& textureName);
	void SetTile(const std::string& animationName);
	void SetFillColor(sf::Color color);

	sf::Color GetFillColor();

protected:
	sf::RectangleShape Shape;
	std::string CurrentTexture;
	std::string CurrentTile;

	StaticTileData TileData;
};