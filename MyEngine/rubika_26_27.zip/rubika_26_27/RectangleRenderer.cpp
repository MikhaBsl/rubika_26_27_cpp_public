#include "RectangleRenderer.h"
#include <TextureMgr.h>
#include <SFML/Graphics/Shader.hpp>
#include <Globals.h>

RectangleRenderer::RectangleRenderer()
{
	Drawable = &Shape;
}

RectangleRenderer::~RectangleRenderer()
{
}

void RectangleRenderer::Start()
{
	sf::IntRect rect;
	if (!TileData.IsRevertedX)
	{
		rect.size.x = TileData.SizeX;
		rect.position.x = TileData.StartX;
	}
	else
	{
		rect.size.x = -TileData.SizeX;
		rect.position.x = TileData.StartX + TileData.SizeX;
	}

	if (!TileData.IsRevertedY)
	{
		rect.size.y = TileData.SizeY;
		rect.position.y = TileData.StartY;
	}
	else
	{
		rect.size.y = -TileData.SizeY;
		rect.position.y = TileData.StartY + TileData.SizeY;
	}

	Shape.setSize(sf::Vector2f((float)TileData.SizeX, (float)TileData.SizeY));
	Shape.setTextureRect(rect);
}

void RectangleRenderer::Update(float deltaTime)
{
}

void RectangleRenderer::Destroy()
{
}

void RectangleRenderer::SetFillColor(const sf::Color& color)
{
	Shape.setFillColor(color);
}


void RectangleRenderer::SetTexture(const std::string& textureName)
{
	const TextureData& textureData = gData.TextureMgr->GetTextureData(textureName);
	Shape.setTexture(&textureData.Texture);

	CurrentTexture = textureName;
}

void RectangleRenderer::SetTile(const std::string& tileNameName)
{
	const TextureData& textureData = gData.TextureMgr->GetTextureData(CurrentTexture);
	TileData = textureData.StaticTilesData.at(tileNameName);

	CurrentTile = tileNameName;
}

void RectangleRenderer::SetFillColor(sf::Color color)
{
	Shape.setFillColor(color);
}


sf::Vector2f RectangleRenderer::GetSize()
{
	return Shape.getSize();
}

sf::Color RectangleRenderer::GetFillColor()
{
	return Shape.getFillColor();
}
